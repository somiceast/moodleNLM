{
    "moodle-atto_fontsize-button": {
        "requires": [
            "node"
        ]
    }
}
