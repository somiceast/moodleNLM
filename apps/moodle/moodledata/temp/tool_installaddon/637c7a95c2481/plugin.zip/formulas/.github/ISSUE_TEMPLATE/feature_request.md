---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

## Description of proposed feature

<!-- Add a clear and concise description of the new feature, including a motivation: why do you think this will be useful? -->


## How can the new feature be used?

<!-- If possible, illustrate how this new feature could be used. -->


## Additional comments

<!-- Add further context that you think might be relevant. -->
